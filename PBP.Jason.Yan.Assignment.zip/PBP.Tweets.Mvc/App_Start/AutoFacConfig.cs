﻿using System.Configuration;
using System.Reflection;
using System.Web.Mvc;
using Autofac;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Autofac.Integration.Mvc;
using TwitterApiWrapper.Services;

namespace PBP.Tweets.Mvc
{
    public static class AutoFacConfig
    {
        public static void RegisterService()
        {
            var builder = new ContainerBuilder();
            builder.RegisterControllers(Assembly.GetExecutingAssembly());

            var oAuthConsumerKey = ConfigurationManager.AppSettings["OAuthConsumerKey"];
            var consumerSecret = ConfigurationManager.AppSettings["ConsumerSecret"];
            var oAuthToken = ConfigurationManager.AppSettings["OAuthToken"];
            var tokenSecret = ConfigurationManager.AppSettings["TokenSecret"];
            builder.Register(c => new TwitterStatusService(oAuthConsumerKey, consumerSecret, oAuthToken, tokenSecret)).As<ITwitterStatusService>();

            IContainer container = builder.Build();
            DependencyResolver.SetResolver(new AutofacDependencyResolver(container));
        }
    }
}