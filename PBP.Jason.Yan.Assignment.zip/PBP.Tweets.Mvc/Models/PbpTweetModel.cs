﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using TwitterApiWrapper.TwitterEntities;

namespace PBP.Tweets.Mvc.Models
{
    public class PbpTweetModel
    {
        public List<Dictionary<string, int>> AmountPerAccount { get; set; }
        public IEnumerable<TwitterStatus> Tweets { get; set; }
        public List<Dictionary<string, List<Dictionary<string, int>>>> UserMentionsPerAccount { get; set; }

        public PbpTweetModel()
        {
            AmountPerAccount = new List<Dictionary<string, int>>();
            Tweets = new List<TwitterStatus>();
            UserMentionsPerAccount = new List<Dictionary<string, List<Dictionary<string, int>>>>();
        }
    }
}