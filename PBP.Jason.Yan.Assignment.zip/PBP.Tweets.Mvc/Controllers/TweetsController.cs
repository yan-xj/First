﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PBP.Tweets.Mvc.Models;
using TwitterApiWrapper.Services;
using TwitterApiWrapper.TwitterEntities;

namespace PBP.Tweets.Mvc.Controllers
{
    public class TweetsController : Controller
    {
        private readonly ITwitterStatusService _twitterStatusService;

        public TweetsController(ITwitterStatusService twitterStatusService)
        {
            _twitterStatusService = twitterStatusService;
        }

        public JsonResult LatestList(string userMention)
        {
            if (string.IsNullOrWhiteSpace(userMention)) 
                return null;

            var content = GetContent(userMention);

            return Json(content, "application/json", JsonRequestBehavior.AllowGet);
        }

        [NonAction]
        private PbpTweetModel GetContent(string user)
        {
            var pbp = new PbpTweetModel();

            var tweets = _twitterStatusService.GetStatus("PayByPhone");
            GetUserMentions(pbp, tweets, "PayByPhone", user);

            tweets = _twitterStatusService.GetStatus("pay_by_phone");
            GetUserMentions(pbp, tweets, "pay_by_phone", user);

            tweets = _twitterStatusService.GetStatus("PayByPhone_UK");
            GetUserMentions(pbp, tweets, "PayByPhone_UK", user);

            return pbp;
        }

        [NonAction]
        private void GetUserMentions(PbpTweetModel pbp, IEnumerable<TwitterStatus> tweets, string screenName,string user)
        {
            pbp.Tweets = pbp.Tweets.Union(tweets);

            pbp.AmountPerAccount.Add(new Dictionary<string, int> {{screenName, tweets.Count()}});

            var amount1 = tweets.Sum(t => t.Entities != null && t.Entities.Mentions != null
                                        ? t.Entities.Mentions.Count(u => u.Name.Equals(user, StringComparison.OrdinalIgnoreCase)): 0);

            var userMention = new List<Dictionary<string, List<Dictionary<string, int>>>>
                                  {
                                      new Dictionary<string, List<Dictionary<string, int>>>
                                          {
                                              {
                                                  screenName,
                                                  new List<Dictionary<string, int>>
                                                      {
                                                          new Dictionary<string, int> {{user, amount1}},
                                                      }
                                              }
                                          }
                                  };

            pbp.UserMentionsPerAccount = pbp.UserMentionsPerAccount.Union(userMention).ToList();
        }
    }
}

