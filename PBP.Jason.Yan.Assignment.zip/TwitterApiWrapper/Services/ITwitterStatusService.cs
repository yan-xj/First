﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TwitterApiWrapper.TwitterEntities;

namespace TwitterApiWrapper.Services
{
    public interface ITwitterStatusService
    {
        IEnumerable<TwitterStatus> GetStatus(string screenName);
        string GetStatusJson(string screenName);
    }
}
