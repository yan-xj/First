﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TwitterApiWrapper.Helpers;
using TwitterApiWrapper.TwitterEntities;

namespace TwitterApiWrapper.Services
{
    public class TwitterStatusService : ITwitterStatusService
    {
        public TwitterStatusService()
        {
        }

        public TwitterStatusService(string consumerKey, string consumerSecret, string oAuthToken, string tokenSecret)
        {
            OAuthConsumerKey = consumerKey;
            ConsumerSecret = consumerSecret;
            OAuthToken = oAuthToken;
            TokenSecret = tokenSecret;
        }

        public string OAuthConsumerKey { get; set; }
        public string ConsumerSecret { get; set; }
        public string TokenSecret { get; set; }
        public string OAuthToken { get; set; }

        public string TwitterApiUrl
        {
            get { return @"https://api.twitter.com/1.1/statuses/user_timeline.json"; }
        }

        public int TimeSpan
        {
            get { return 21; }
        }

        public int TweetsCount
        {
            get { return 20; }
        }

        public IEnumerable<TwitterStatus> GetStatus(string screenName)
        {
            var jsonString = GetStatusJson(screenName);

            var result = ParseJsonHelper.MapJsonToStatus(jsonString);
            if (!result.Any())
                return null;

            var interval = DateTime.UtcNow.DayOfYear - TimeSpan;
            if (result.Any(r => r.CreatedDate.DayOfYear < interval))
            {
                return result.Where(r => r.CreatedDate.DayOfYear >= interval).ToList();
            }

            var maxId = result.Min(r => r.Id);

            while (true)
            {
                var moreResult = ParseJsonHelper.MapJsonToStatus(GetStatusJson(screenName, maxId));

                if (!moreResult.Any())
                    return result;

                if (moreResult.Any(r => r.CreatedDate.DayOfYear < interval))
                    return result.Union(moreResult.Where(r => r.CreatedDate.DayOfYear >= interval).ToList());

                maxId = moreResult.Min(r => r.Id);

                result = result.Union(moreResult);
            }
        }

        public string GetStatusJson(string screenName, long maxId = 0)
        {
            var queryPairs = new Dictionary<string, string>
                                 {
                                     {"screen_name", screenName},
                                     {"count", TweetsCount.ToString()}
                                 };

            if (maxId > 0)
                queryPairs.Add("max_id", maxId.ToString());

            var sb = new StringBuilder();
            foreach (var key in queryPairs.Keys)
            {
                sb.AppendFormat("{0}={1}&", key, queryPairs[key]);
            }
            sb.Remove(sb.Length - 1, 1);

            var url = string.Format("{0}?{1}", TwitterApiUrl, sb);

            return GetStatusJson(url, queryPairs, "GET");
        }

        public string GetStatusJson(string url, IDictionary<string, string> queryPairs, string method)
        {
            var oAuthHelper = new OAuthHelper(OAuthConsumerKey, ConsumerSecret, OAuthToken, TokenSecret);
            var signature = oAuthHelper.CreateAuthorizationHeaderParameter(TwitterApiUrl, queryPairs, method);
            var request = HttpHelper.CreateRequest(url, signature, method);

            return HttpHelper.GetResponse(request);
        }

        public string GetStatusJson(string screenName)
        {
            return GetStatusJson(screenName, 0);
        }
    }
}
