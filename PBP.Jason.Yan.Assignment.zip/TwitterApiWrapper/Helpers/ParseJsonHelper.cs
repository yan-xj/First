﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using TwitterApiWrapper.TwitterEntities;

namespace TwitterApiWrapper.Helpers
{
    public static class ParseJsonHelper
    {
        public static IEnumerable<TwitterStatus> MapJsonToStatus(string jsonContent)
        {
            var statuses = new List<TwitterStatus>();

            var data = new JavaScriptSerializer().Deserialize<dynamic>(jsonContent);

            foreach (dynamic item in data)
            {
                if (item == null) continue;
                var dictionary = (Dictionary<string, object>)item;
                var tweet = new TwitterStatus();
                if (dictionary.ContainsKey("in_reply_to_screen_name"))
                {
                    tweet.Id = item["id"];
                    tweet.IdStr = item["id_str"];
                    tweet.Text = item["text"];
                    tweet.CreatedDate = DateTime.ParseExact(item["created_at"], "ddd MMM dd HH:mm:ss zzz yyyy", CultureInfo.InvariantCulture).ToUniversalTime();

                    if (dictionary.ContainsKey("user"))
                    {
                        tweet.User = new TwitterUser();
                        tweet.User.Id = item["user"]["id"];
                        tweet.User.Name = item["user"]["name"];
                        tweet.User.ScreenName = item["user"]["screen_name"];
                    }

                    if (dictionary.ContainsKey("entities"))
                    {
                        var um = item["entities"]["user_mentions"] as object[];
                        if (um != null && um.Length > 0)
                        {
                            tweet.Entities = new TwitterEntities.TwitterEntities();
                            tweet.Entities.Mentions = new List<TwitterUserMention>();

                            for (int i = 0; i < um.Length; i++)
                            {
                                var mention = new TwitterUserMention();
                                mention.Id = item["entities"]["user_mentions"][i]["id"];
                                mention.IdStr = item["entities"]["user_mentions"][i]["id_str"];
                                mention.Name = item["entities"]["user_mentions"][i]["name"];
                                mention.ScreenName = item["entities"]["user_mentions"][i]["screen_name"];

                                tweet.Entities.Mentions.Add(mention);
                            }
                        }
                    }
                }

                statuses.Add(tweet);
            }

            Debug.Print(statuses.Count.ToString());

            return statuses;
        }
    }
}
