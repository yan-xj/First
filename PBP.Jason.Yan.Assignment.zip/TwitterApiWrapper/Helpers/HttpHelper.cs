﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace TwitterApiWrapper.Helpers
{
    public static class HttpHelper
    {
        public static string GetResponse(HttpWebRequest request)
        {
            ServicePointManager.Expect100Continue = false;

            using (var response = request.GetResponse() as HttpWebResponse)
            {
                if (response != null && response.StatusCode != HttpStatusCode.OK)
                {
                    throw new ApplicationException(string.Format("The request did not complete properly. Status code:{0}", response.StatusCode));
                }

                using (var reader = new StreamReader(response.GetResponseStream()))
                {
                    return reader.ReadToEnd();
                }
            }
        }

        public static HttpWebRequest CreateRequest(string url, string authorizationHeaderParams, string method)
        {
            var request = (HttpWebRequest) WebRequest.Create(url);

            if (!string.IsNullOrWhiteSpace(authorizationHeaderParams))
                request.Headers.Add("Authorization", authorizationHeaderParams);
            
            request.Method = method;
            request.Timeout = 3*60*1000;

            return request;
        }
    }
}
