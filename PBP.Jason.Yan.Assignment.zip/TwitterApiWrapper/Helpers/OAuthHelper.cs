﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace TwitterApiWrapper.Helpers
{
    public class OAuthHelper
    {
        private readonly string _oathTimestamp;
        private readonly string _oauthNonce;

        public OAuthHelper()
        {
            _oauthNonce = Convert.ToBase64String(new ASCIIEncoding().GetBytes(DateTime.Now.Ticks.ToString(CultureInfo.InvariantCulture)));
            var timeSpan = DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0);
            _oathTimestamp = Convert.ToInt64(timeSpan.TotalSeconds).ToString(CultureInfo.InvariantCulture);
        }

        public OAuthHelper(string consumerKey, string consumerSecret, string oAuthToken, string tokenSecret) : this()
        {
            OAuthConsumerKey = consumerKey;
            ConsumerSecret = consumerSecret;
            OAuthToken = oAuthToken;
            TokenSecret = tokenSecret;
        }

        public string OAuthConsumerKey { get; set; }
        public string ConsumerSecret { get; set; }
        public string TokenSecret { get; set; }
        public string OAuthToken { get; set; }

        public string OAuthTimeStamp
        {
            get { return _oathTimestamp; }
        }

        public string OAuthSignatureMethod
        {
            get { return "HMAC-SHA1"; }
        }

        public string OAuthVersion
        {
            get { return "1.0"; }
        }

        public string OAuthNonce
        {
            get { return _oauthNonce; }
        }


        string CreateSignature(string url, IDictionary<string, string> queryPairs, string httpMethod)
        {
            var dictionary = new SortedDictionary<string, string>
                                 {
                                     {"oauth_version", OAuthVersion},
                                     {"oauth_consumer_key", OAuthConsumerKey},
                                     {"oauth_nonce", OAuthNonce},
                                     {"oauth_signature_method", OAuthSignatureMethod},
                                     {"oauth_timestamp", OAuthTimeStamp},
                                     {"oauth_token", OAuthToken}
                                 };

            foreach (var key in queryPairs.Keys)
            {
                dictionary.Add(key, queryPairs[key]);
            }

            var sb = new StringBuilder();
            sb.Append(httpMethod.Trim().ToUpper());
            sb.Append("&");

            sb.Append(Uri.EscapeDataString(url));
            sb.Append("&");
            foreach (var entry in dictionary)
            {
                sb.Append(Uri.EscapeDataString(string.Format("{0}={1}&", entry.Key, entry.Value)));
            }
            var baseString = sb.ToString().Substring(0, sb.Length - 3);

            var signingKey = Uri.EscapeDataString(ConsumerSecret) + "&" + Uri.EscapeDataString(TokenSecret);

            var hasher = new HMACSHA1(new ASCIIEncoding().GetBytes(signingKey));

            var signatureString = Convert.ToBase64String(hasher.ComputeHash(new ASCIIEncoding().GetBytes(baseString)));

            return signatureString;
        }

        string CreateAuthorizationHeaderParameter(string signature)
        {
            return string.Format(
                    "OAuth oauth_nonce=\"{0}\",oauth_signature_method=\"{1}\",oauth_timestamp=\"{2}\",oauth_consumer_key=\"{3}\",oauth_token=\"{4}\",oauth_signature=\"{5}\",oauth_version=\"{6}\""
                    , Uri.EscapeDataString(OAuthNonce)
                    , Uri.EscapeDataString(OAuthSignatureMethod)
                    , Uri.EscapeDataString(OAuthTimeStamp)
                    , Uri.EscapeDataString(OAuthConsumerKey)
                    , Uri.EscapeDataString(OAuthToken)
                    , Uri.EscapeDataString(signature)
                    , Uri.EscapeDataString(OAuthVersion));
        }

        public string CreateAuthorizationHeaderParameter(string url, IDictionary<string, string> queryPairs, string httpMethod)
        {
            var signature = CreateSignature(url, queryPairs, httpMethod);

            return CreateAuthorizationHeaderParameter(signature);
        }
    }
}
