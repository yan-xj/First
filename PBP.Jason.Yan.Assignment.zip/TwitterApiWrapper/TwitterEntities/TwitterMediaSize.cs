﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwitterApiWrapper.TwitterEntities
{
    public class TwitterMediaSize
    {
        public virtual string Resize { get; set; }
        public virtual int Width { get; set; }
        public virtual int Height { get; set; }
    }
}
