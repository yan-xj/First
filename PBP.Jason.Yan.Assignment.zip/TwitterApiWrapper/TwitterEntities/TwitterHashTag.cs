﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwitterApiWrapper.TwitterEntities
{
    public class TwitterHashTag : TwitterEntity
    {
        public virtual string Text { get; set; }
    }
}
