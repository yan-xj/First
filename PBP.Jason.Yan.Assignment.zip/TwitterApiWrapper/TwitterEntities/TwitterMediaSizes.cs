﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwitterApiWrapper.TwitterEntities
{
    public class TwitterMediaSizes : IEnumerable<TwitterMediaSize>
    {
        public virtual TwitterMediaSize Thumb { get; set; }
        public virtual TwitterMediaSize Small { get; set; }
        public virtual TwitterMediaSize Medium { get; set; }
        public virtual TwitterMediaSize Large { get; set; }

        public IEnumerator<TwitterMediaSize> GetEnumerator()
        {
            return Coalesce().GetEnumerator();
        }

        private IEnumerable<TwitterMediaSize> Coalesce()
        {
            var sizes = new List<TwitterMediaSize>();
            if (Thumb != null)
            {
                sizes.Add(Thumb);
            }
            if (Small != null)
            {
                sizes.Add(Small);
            }
            if (Medium != null)
            {
                sizes.Add(Medium);
            }
            if (Large != null)
            {
                sizes.Add(Large);
            }
            return sizes;
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}
