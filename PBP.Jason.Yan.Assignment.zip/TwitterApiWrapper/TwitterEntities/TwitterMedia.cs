﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwitterApiWrapper.TwitterEntities
{
    public partial class TwitterMedia : TwitterEntity
    {
        public virtual long Id { get; set; }
        public virtual string IdAsString { get; set; }
        public virtual string MediaUrl { get; set; }
        public virtual string MediaUrlHttps { get; set; }
        public virtual string Url { get; set; }
        public virtual string DisplayUrl { get; set; }
        public virtual string ExpandedUrl { get; set; }
        public virtual TwitterMediaType MediaType { get; set; }
        public virtual TwitterMediaSizes Sizes { get; set; }
    }

    public enum TwitterMediaType
    {
        Photo
    }
}
