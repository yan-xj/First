﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwitterApiWrapper.TwitterEntities
{
    public class TwitterUserMention : TwitterEntity
    {
        public virtual long Id { get; set; }
        public virtual string IdStr { get; set; }
        public virtual string ScreenName { get; set; }
        public virtual string Name { get; set; }
    }
}
