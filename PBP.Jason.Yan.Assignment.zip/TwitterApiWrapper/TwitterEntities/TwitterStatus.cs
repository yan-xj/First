﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwitterApiWrapper.TwitterEntities
{
    public class TwitterStatus : IComparable<TwitterStatus>,
                                 IEquatable<TwitterStatus>,
                                 ITweetable
    {
        public virtual long Id { get; set; }
        public virtual string IdStr { get; set; }
        public virtual int? InReplyToUserId { get; set; }
        public virtual long? InReplyToStatusId { get; set; }
        public virtual string InReplyToScreenName { get; set; }
        public virtual bool IsTruncated { get; set; }
        public virtual bool IsFavorited { get; set; }
        public virtual int RetweetCount { get; set; }
        public virtual string Text { get; set; }
        public virtual string Source { get; set; }
        public virtual TwitterUser User { get; set; }
        public virtual TwitterStatus RetweetedStatus { get; set; }
        public virtual DateTime CreatedDate { get; set; }
        public virtual TwitterGeoLocation Location { get; set; }
        public virtual string Language { get; set; }
        public virtual TwitterEntities Entities { get; set; }
        public virtual bool? IsPossiblySensitive { get; set; }
        public virtual TwitterPlace Place { get; set; }
        public virtual string RawSource { get; set; }

        private string _textAsHtml;
        public virtual string TextAsHtml
        {
            get
            {
                _textAsHtml = "not implement yet";
                return _textAsHtml;
            }
            set { _textAsHtml = value; }
        }

        private string _textDecoded;
        public virtual string TextDecoded
        {
            get
            {
                _textDecoded = "not implment yet.";
                return _textDecoded;
            }
            set { _textDecoded = value; }
        }

        public ITweeter Author
        {
            get { return User; }
        }


        public int CompareTo(TwitterStatus other)
        {
            return other.Id == Id ? 0 : other.Id > Id ? -1 : 1;
        }

        public bool Equals(TwitterStatus status)
        {
            if (ReferenceEquals(null, status))
            {
                return false;
            }
            if (ReferenceEquals(this, status))
            {
                return true;
            }
            return status.Id == Id;
        }

        public override bool Equals(object status)
        {
            if (ReferenceEquals(null, status))
            {
                return false;
            }
            if (ReferenceEquals(this, status))
            {
                return true;
            }
            return status.GetType() == typeof(TwitterStatus) && Equals((TwitterStatus)status);
        }

        public override int GetHashCode()
        {
            return Id.GetHashCode();
        }

        public static bool operator ==(TwitterStatus left, TwitterStatus right)
        {
            return Equals(left, right);
        }

        public static bool operator !=(TwitterStatus left, TwitterStatus right)
        {
            return !Equals(left, right);
        }
    }
}
