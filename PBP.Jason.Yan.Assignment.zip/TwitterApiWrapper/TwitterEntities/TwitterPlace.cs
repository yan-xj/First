﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwitterApiWrapper.TwitterEntities
{
    public enum TwitterPlaceType
    {
        City,
        Neighborhood,
        Country,
        Admin,
        POI
    }

    public class TwitterPlace : IComparable<TwitterPlace>,
                                IEquatable<TwitterPlace>,
                                ITwitterModel
    {
        public virtual string Id { get; set; }
        public virtual string Name { get; set; }
        public virtual string FullName { get; set; }
        public virtual string Country { get; set; }
        public virtual string CountryCode { get; set; }
        public virtual string Url { get; set; }
        public virtual TwitterPlaceType PlaceType { get; set; }
        public virtual IEnumerable<TwitterPlace> ContainedWithin { get; set; }
        public virtual string RawSource { get; set; }

        public int CompareTo(TwitterPlace other)
        {
            return String.Compare(Id, other.Id, StringComparison.Ordinal);
        }

        public bool Equals(TwitterPlace other)
        {
            if (ReferenceEquals(null, other)) return false;
            return ReferenceEquals(this, other) || Equals(other.Id, Id);
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;
            return obj.GetType() == typeof(TwitterPlace) && Equals((TwitterPlace)obj);
        }

        public override int GetHashCode()
        {
            return (Id != null ? Id.GetHashCode() : 0);
        }

        public static bool operator ==(TwitterPlace left, TwitterPlace right)
        {
            return Equals(left, right);
        }

        public static bool operator !=(TwitterPlace left, TwitterPlace right)
        {
            return !Equals(left, right);
        }
    }
}
