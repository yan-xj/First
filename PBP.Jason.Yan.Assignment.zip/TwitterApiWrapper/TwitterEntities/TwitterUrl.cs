﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwitterApiWrapper.TwitterEntities
{
    public class TwitterUrl : TwitterEntity
    {
        public virtual string Url { get; set; }
        public virtual string ExpandedUrl { get; set; }
        public virtual string DisplayUrl { get; set; }
    }
}
