﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwitterApiWrapper.TwitterEntities
{
    public class TwitterEntities
    {
        public virtual IList<TwitterUserMention> Mentions { get; set; }
        public virtual IList<TwitterHashTag> HashTags { get; set; }
        public virtual IList<TwitterUrl> Urls { get; set; }
        public virtual IList<TwitterMedia> Media { get; set; }
    }

    public abstract class TwitterEntity : IComparable<TwitterEntity>, IComparer<TwitterEntity>
    {
        public virtual IList<int> Indices { get; set; }

        public virtual int StartIndex
        {
            get { return Indices != null ? (Indices.Count > 0 ? Indices[0] : -1) : 0; }
        }

        public virtual int EndIndex
        {
            get { return Indices != null ? (Indices.Count > 1 ? Indices[1] : -1) : 0; }
        }

        public virtual int CompareTo(TwitterEntity other)
        {
            return StartIndex.CompareTo(other.StartIndex);
        }

        public virtual int Compare(TwitterEntity x, TwitterEntity y)
        {
            return x.StartIndex.CompareTo(y.StartIndex);
        }
    }
}
