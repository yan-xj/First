﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwitterApiWrapper.TwitterEntities
{
    public class TwitterUser : IComparable<TwitterUser>,
                               IEquatable<TwitterUser>,
                               ITweeter
    {
        public virtual long Id { get; set; }
        public virtual int FollowersCount { get; set; }
        public virtual string Name { get; set; }
        public virtual string Description { get; set; }
        public virtual string ProfileImageUrl { get; set; }
        public virtual string Url { get; set; }
        public virtual bool? IsProtected { get; set; }
        public virtual string ScreenName { get; set; }
        public virtual string Location { get; set; }
        public virtual TwitterStatus Status { get; set; }
        public virtual int FriendsCount { get; set; }
        public virtual string ProfileBackgroundColor { get; set; }
        public virtual string UtcOffset { get; set; }
        public virtual string ProfileTextColor { get; set; }
        public virtual string ProfileBackgroundImageUrl { get; set; }
        public virtual string TimeZone { get; set; }
        public virtual int FavouritesCount { get; set; }
        public virtual int ListedCount { get; set; }
        public virtual string ProfileLinkColor { get; set; }
        public virtual int StatusesCount { get; set; }
        public virtual string ProfileSidebarFillColor { get; set; }
        public virtual string ProfileSidebarBorderColor { get; set; }
        public virtual bool IsProfileBackgroundTiled { get; set; }
        public virtual bool? IsVerified { get; set; }
        public virtual bool? IsGeoEnabled { get; set; }
        public virtual string Language { get; set; }
        public virtual DateTime CreatedDate { get; set; }
        public virtual bool? FollowRequestSent { get; set; }
        public virtual bool? IsTranslator { get; set; }
        public virtual bool? ContributorsEnabled { get; set; }
        public virtual string ProfileBackgroundImageUrlHttps { get; set; }
        public virtual string ProfileImageUrlHttps { get; set; }
        public virtual bool? IsDefaultProfile { get; set; }
        public virtual string RawSource { get; set; }


        public int CompareTo(TwitterUser user)
        {
            return user.Id == Id ? 0 : user.Id > Id ? -1 : 1;
        }


        public bool Equals(TwitterUser user)
        {
            if (ReferenceEquals(null, user))
            {
                return false;
            }
            if (ReferenceEquals(this, user))
            {
                return true;
            }
            return user.Id == Id;
        }


        public override bool Equals(object user)
        {
            if (ReferenceEquals(null, user))
            {
                return false;
            }
            if (ReferenceEquals(this, user))
            {
                return true;
            }
            return user.GetType() == typeof(TwitterUser) && Equals((TwitterUser)user);
        }

        public override int GetHashCode()
        {
            return Id.GetHashCode();
        }

        public static bool operator ==(TwitterUser left, TwitterUser right)
        {
            return Equals(left, right);
        }

        public static bool operator !=(TwitterUser left, TwitterUser right)
        {
            return !Equals(left, right);
        }
    }
}
