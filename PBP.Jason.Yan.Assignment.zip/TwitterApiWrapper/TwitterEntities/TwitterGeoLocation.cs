﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwitterApiWrapper.TwitterEntities
{
    public class TwitterGeoLocation : IEquatable<TwitterGeoLocation>,
                                      ITwitterModel
    {
        public class GeoCoordinates
        {
            public virtual double Latitude { get; set; }
            public virtual double Longitude { get; set; }
            public static explicit operator double[](GeoCoordinates location)
            {
                return new[] { location.Latitude, location.Longitude };
            }

            public static implicit operator GeoCoordinates(List<double> values)
            {
                return FromEnumerable(values);
            }

            public static implicit operator GeoCoordinates(double[] values)
            {
                return FromEnumerable(values);
            }

            private static GeoCoordinates FromEnumerable(IEnumerable<double> values)
            {
                if (values == null)
                {
                    throw new ArgumentNullException("values");
                }

                var latitude = values.First();
                var longitude = values.Skip(1).Take(1).Single();

                return new GeoCoordinates { Latitude = latitude, Longitude = longitude };
            }
        }

        private static readonly TwitterGeoLocation _none = new TwitterGeoLocation();
        private GeoCoordinates _coordinates;
        private string _type;

        public TwitterGeoLocation(double latitude, double longitude)
        {
            _coordinates = new GeoCoordinates
            {
                Latitude = latitude,
                Longitude = longitude
            };
        }


        public TwitterGeoLocation()
        {

        }


        public virtual GeoCoordinates Coordinates { get; set; }
        public virtual string Type { get; set; }
        public static TwitterGeoLocation None
        {
            get { return _none; }
        }

        public virtual bool Equals(TwitterGeoLocation other)
        {
            if (ReferenceEquals(null, other))
            {
                return false;
            }
            return other.Coordinates.Latitude == Coordinates.Latitude
                   && other.Coordinates.Longitude == Coordinates.Longitude;
        }

        public override bool Equals(object instance)
        {
            if (ReferenceEquals(null, instance))
            {
                return false;
            }

            return instance.GetType() == typeof(TwitterGeoLocation) && Equals((TwitterGeoLocation)instance);
        }

        public static bool operator ==(TwitterGeoLocation left, TwitterGeoLocation right)
        {
            if (ReferenceEquals(left, right))
            {
                return true;
            }
            if (ReferenceEquals(null, left))
            {
                return false;
            }

            return left.Equals(right);
        }

        public static bool operator !=(TwitterGeoLocation left, TwitterGeoLocation right)
        {
            if (ReferenceEquals(left, right))
            {
                return false;
            }
            if (ReferenceEquals(null, left))
            {
                return true;
            }
            return !left.Equals(right);
        }

        public override int GetHashCode()
        {
            unchecked
            {
                return (Coordinates.Latitude.GetHashCode() * 397) ^ Coordinates.Longitude.GetHashCode();
            }
        }

        public override string ToString()
        {
            return string.Format("{0},{1}", Coordinates.Latitude, Coordinates.Longitude);
        }

        public virtual string RawSource { get; set; }
    }
}
