﻿using System;
using System.Configuration;
using System.IO;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TwitterApiWrapper.Helpers;
using TwitterApiWrapper.Services;
using TwitterApiWrapper.TwitterEntities;

namespace StatusServiceTest
{
    [TestClass]
    public class TwitterApiWrapperUnitTest
    {
        private TwitterStatusService _service;

        [TestInitialize]
        public void Init()
        {
            this._service = new TwitterStatusService(
                "RF7U07p1SOQMNGp8kydQ", 
                "KUUzqjatgmMtt6PmJI383j6DgbyOwuzhg1VTR0pmoO8",
                "1694650724-RFyoDL2g93gz4nVZQg0XlZyJABsK2BHl01dlpGo",
                "o6fpBfme5o2GvIni322HxTZuk8e2ZlZbjWZ6nxXoIU");
        }

        [TestMethod]
        public void Status_List_By_ScreenName_PayByPhone_Should_Have_Tweets()
        {
            string result = this._service.GetStatusJson("PayByPhone");

            Assert.IsTrue(result.Contains("created_at"));
        }

        [TestMethod]
        public void Status_List_By_ScreenName_pay_by_phone_Should_Have_Tweets()
        {
            string result = this._service.GetStatusJson("pay_by_phone");

            Assert.IsTrue(result.Contains("entities"));
        }

        [TestMethod]
        public void Status_List_By_ScreenName_PayByPhone_UK_Should_Have_Tweets()
        {
            string result = this._service.GetStatusJson("PayByPhone_UK");

            Assert.IsTrue(result.Contains("id_str"));
        }

        [TestMethod]
        public void Status_List_By_ScreenName_PayByPhone_IEquatable_All_Tweest_Be_In_Latest_Three_Weeks()
        {
            var result = this._service.GetStatus("PayByPhone");
            var interval = DateTime.UtcNow.DayOfYear - 21;

            Assert.IsTrue(result.All(r => r.CreatedDate.DayOfYear > interval));
        }

        [TestMethod]
        public void Mapping_Json_String_To_Twitter_Status_Works()
        {
            var directory = Directory.GetCurrentDirectory();
            var filename = directory.Replace(@"bin\Debug", @"response.txt");
            var content = File.ReadAllText(filename);

            var result = ParseJsonHelper.MapJsonToStatus(content);

            Assert.IsNotNull(result);
        }
    }
}
