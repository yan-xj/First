﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using PBP.Tweets.Mvc;
using PBP.Tweets.Mvc.Controllers;
using TwitterApiWrapper.Services;

namespace PBP.Tweets.Mvc.Tests.Controllers
{
    [TestClass]
    public class TweetsControllerTest
    {
        [TestMethod]
        public void Tweets_Json_Result_Should_Not_Be_Null()
        {
            var service = new TwitterStatusService(
             "RF7U07p1SOQMNGp8kydQ",
             "KUUzqjatgmMtt6PmJI383j6DgbyOwuzhg1VTR0pmoO8",
             "1694650724-RFyoDL2g93gz4nVZQg0XlZyJABsK2BHl01dlpGo",
             "o6fpBfme5o2GvIni322HxTZuk8e2ZlZbjWZ6nxXoIU");

            TweetsController controller = new TweetsController(service);
            JsonResult content = controller.LatestList("paybyphone") as JsonResult;

            Assert.IsNotNull(content);
        }

        [TestMethod]
        public void Content_Returned_to_Browser_Should_Not_Be_Null()
        {
            var request = TwitterApiWrapper.Helpers.HttpHelper.CreateRequest(@"http://localhost:2039/tweets/latestlist/paybyphone", "", "GET");
            var result = TwitterApiWrapper.Helpers.HttpHelper.GetResponse(request);

            Assert.IsTrue(result.Contains("AmountPerAccount"));
        }
    }
}
